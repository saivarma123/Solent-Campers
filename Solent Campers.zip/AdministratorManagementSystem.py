from tkinter import *

class AdministratorManagementSystem:
    def __init__(self):
        self.__rootScreen = Tk()
        self.__rootScreen.title("Solent Campers")

        self.vanDb = ["Small-S", "Medium-M", "Large-L"]
        self.campDb = ["Mountains", "Beach", "Temple", "Hill Station"]

        self.__sitesFrame = LabelFrame(self.__rootScreen, text="Camping sites options", padx=10, pady=10)
        self.__sitesFrame.pack(padx=10, pady=5)
        Button(self.__sitesFrame, text="Add Camp", padx=5, pady=5, command=self.__addCamp).grid(row=0, column=0)
        Button(self.__sitesFrame, text="Delete Camp", padx=5, pady=5, command=self.__deleteCamp).grid(row=0, column=1)


        self.__vansFrame = LabelFrame(self.__rootScreen, text="Camper vans options", padx=10, pady=10)
        self.__vansFrame.pack(padx=10, pady=5)
        Button(self.__vansFrame, text="Add Van", padx=5, pady=5, command=self.__addVan).grid(row=0, column=0)
        Button(self.__vansFrame, text="Delete Van", padx=5, pady=5, command=self.__deleteVan).grid(row=0, column=1)

    def showAdministratorScreen(self):
        self.__rootScreen.mainloop()

    def __addCamp(self):
        addCampScreen = Tk()
        addCampScreen.title("Add Camp")

        campNameLabel = Label(addCampScreen, text="Camp Name")
        campNameLabel.grid(row=0, column=0, padx=5, pady=5)
        campNameInput = Entry(addCampScreen)
        campNameInput.grid(row=0, column=1, padx=5, pady=5)

        campButton = Button(addCampScreen, text="Add Camp", command=lambda: self.__onAddCamp(addCampScreen,campNameInput.get())).grid(row=1, column=1)

        addCampScreen.mainloop()

    def __onAddCamp(self, addCampScreen, campName):
        self.campDb.append(campName)
        addCampScreen.destroy()

    def __deleteCamp(self):
        deleteCampScreen = Tk()
        deleteCampScreen.title("Delete Camp")

        campList = Listbox(deleteCampScreen)
        campList.pack(padx=5, pady=5)

        for idx, camp in enumerate(self.campDb):
            campList.insert(idx, camp)

        deleteCampButton = Button(deleteCampScreen, text="Delete Camp", command=lambda: self.__onDeleteCamp(campList,deleteCampScreen))
        deleteCampButton.pack(padx=10, pady=15, anchor=W)

        deleteCampScreen.mainloop()
    
    def __onDeleteCamp(self, campList, deleteCampScreen):
        index = campList.curselection()
        if not index: return
        if index: del self.campDb[index[0]]
        
        deleteCampScreen.destroy()

    def __addVan(self):
        addVanScreen = Tk()
        addVanScreen.title("Add Van")

        vanNameLabel = Label(addVanScreen, text="Van Name")
        vanNameLabel.grid(row=0, column=0, padx=5, pady=5)
        vanNameInput = Entry(addVanScreen)
        vanNameInput.grid(row=0, column=1, padx=5, pady=5)

        vanButton = Button(addVanScreen, text="Add Van", command=lambda: self.__onAddVan(addVanScreen,vanNameInput.get())).grid(row=1, column=1)

        addVanScreen.mainloop()

    def __onAddVan(self, addVanScreen, vanName):
        self.vanDb.append(vanName)
        addVanScreen.destroy()

    def __deleteVan(self):
        deleteVanScreen = Tk()
        deleteVanScreen.title("Delete Van")

        vanList = Listbox(deleteVanScreen)
        vanList.pack(padx=5, pady=5)

        for idx, van in enumerate(self.vanDb):
            vanList.insert(idx, van)

        deleteVanButton = Button(deleteVanScreen, text="Delete Van", command=lambda: self.__onDeleteVan(vanList,deleteVanScreen))
        deleteVanButton.pack(padx=10, pady=15, anchor=W)

        deleteVanScreen.mainloop()
    
    def __onDeleteVan(self, vanList, deleteVanScreen):
        index = vanList.curselection()
        if not index: return
        if index: del self.vanDb[index[0]]
        
        deleteVanScreen.destroy()