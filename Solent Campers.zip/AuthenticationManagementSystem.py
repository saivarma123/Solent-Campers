from tkinter import *
from state import *
from model import *


class AuthenticationManagementSystem:
    def __init__(self):
        self.__rootScreen = Tk()
        self.__rootScreen.title("Solent Campers")
        self.__userTypes = [Constants.admin, Constants.advisor, Constants.customer]
        self.selectedUser = StringVar()

    def showUserSelection(self):
        self.selectedUser.trace("w", self.__onSelectedUserChange)

        self.__setCurrentUser(self.selectedUser.get())

        frame = Frame(self.__rootScreen)
        label = Label(frame, text="Selected user is: ")
        label.grid(row=0, column=0, padx=10)

        selectedUserOption = OptionMenu(frame, self.selectedUser, *self.__userTypes)
        selectedUserOption.grid(row=0, column=1, padx=10, pady=5)

        frame.pack()
        self.__rootScreen.mainloop()

    def __onSelectedUserChange(self, *args):
        self.__setCurrentUser(self.selectedUser.get())
        ApplicationState.isAuthenticated = True
        self.__rootScreen.destroy()

    def __setCurrentUser(self, user):
        if user == Constants.admin:
            ApplicationState.currentUser = UserLevel.ADMIN
        if user == Constants.advisor:
            ApplicationState.currentUser = UserLevel.ADVISOR
        if user == Constants.customer:
            ApplicationState.currentUser = UserLevel.CUSTOMER
