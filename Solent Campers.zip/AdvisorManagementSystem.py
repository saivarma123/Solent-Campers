from tkinter import *
from tkinter import messagebox

class AdvisorManagementSystem:
    def __init__(self) -> None:
        self.__rootScreen = Tk()
        self.__rootScreen.title("Solent Campers")

        self.vansDb = [["Small (S)",3],["Medium (M)",1],["Large (L)",0]]
        self.campDb = [["Mountains",3], ["Beach",10], ["Hill Station",5]]

        self.bookingsDb = [
            {
                "title": "A sample trip",
                "camperVan": "Medium-M",
                "camps": "Mountain"
            }
        ]


        self.__tripsFrame = LabelFrame(self.__rootScreen, text="Trip options for Advisor", padx=10, pady=10)
        self.__tripsFrame.pack(padx=10, pady=5)
        Button(self.__tripsFrame, text="Book Trip", padx=5, pady=5, command=self.__bookTrip).grid(row=0, column=0)
        Button(self.__tripsFrame, text="View Trips", padx=5, pady=5, command=self.__viewTrips).grid(row=0, column=2)
    
    def showAdvisorScreen(self):
        self.__rootScreen.mainloop()
    
    def __viewTrips(self):
        viewTripsScreen = Tk()
        viewTripsScreen.title("View a summary of booked trips")

        tripList = Listbox(viewTripsScreen)
        tripList.pack(padx=5, pady=5)

        for idx, trip in enumerate(self.bookingsDb):
            tripList.insert(idx, trip["title"])


        Button(viewTripsScreen,text="Display Summary", padx=5, pady=5,command=lambda:self.__onViewTrips(tripList,summaryLabel)).pack()

        summaryLabel = Label(viewTripsScreen, text="Select a trip to see summary")
        summaryLabel.pack(pady=5,padx=10)

        viewTripsScreen.mainloop()
    
    def __onViewTrips(self, tripList, summaryLabel):
        index = tripList.curselection()
        if not index: return
        trip = self.bookingsDb[index[0]]
        tripSummary = f"{trip['title']} summary\n\nCamper Van: {trip['camperVan']}\nCamp Spot: {trip['camps']}"
        summaryLabel.config(text=tripSummary)

    def __bookTrip(self):
        bookTripScreen = Tk()
        bookTripScreen.title("Book a trip for customer")

        tripNameLabel = Label(bookTripScreen, text="Trip Name")
        tripNameLabel.grid(row=0, column=0, padx=5, pady=5)
        tripNameInput = Entry(bookTripScreen)
        tripNameInput.grid(row=0, column=1, padx=5, pady=5)

        tripCamperVanLabel = Label(bookTripScreen, text="")
        tripCamperVanLabel.grid(row=1, column=1, padx=5, pady=5)
        Button(bookTripScreen, text="Select Camping Van", padx=5, pady=5, command=
            lambda:self.__selectVan(tripCamperVanLabel)).grid(row=1, column=0)

        tripCampsLabel = Label(bookTripScreen, text="")
        tripCampsLabel.grid(row=2, column=1, padx=5, pady=5)
        Button(bookTripScreen, text="Select Camping site", padx=5, pady=5,command=
            lambda:self.__selectCamp(tripCampsLabel)).grid(row=2, column=0)

        Button(bookTripScreen, text="Book Trip", padx=5, pady=10, command=lambda:self.__onBookTrip(
            tripNameInput.get(),
            tripCamperVanLabel.cget("text"),
            tripCampsLabel.cget("text"),
            bookTripScreen
        )).grid(row=3, column=0)

        bookTripScreen.mainloop()

    def __onBookTrip(self,title,van,camp,bookTripScreen):
        if not title or not van or not camp:
            return
        
        booking = dict()
        booking["title"] = title
        booking["camperVan"] = van
        booking["camps"] = camp

        self.bookingsDb.append(booking)
        bookTripScreen.destroy()

    
    def __selectVan(self, label):
        selectVanScreen = Tk()
        selectVanScreen.title("Select trip van")
        Label(selectVanScreen, text="Van Type-Availability").pack(padx=10,pady=15)

        vanList = Listbox(selectVanScreen)
        vanList.pack(padx=5, pady=5)
                
        for idx, van in enumerate(self.vansDb):
            vanList.insert(idx, f"{van[0]} - {van[1]}")


        Button(selectVanScreen, text="Select Vans", padx=5, pady=5, command=lambda: self.__onSelectVan(
            vanList,label,selectVanScreen)).pack()

        selectVanScreen.mainloop()

    def __onSelectVan(self, vanList, label, selectVanScreen):
        index = vanList.curselection()
        if not index: return

        van = self.vansDb[index[0]]

        if(van[1] == 0):
            messagebox.showerror("Not Available", "This van is not available anymore")
            selectVanScreen.destroy()
            return

        label.config(text=van[0])
        self.vansDb[index[0]][1] -= 1

        selectVanScreen.destroy()

    def __selectCamp(self, label):
        selectCampScreen = Tk()
        selectCampScreen.title("Select trip camp")
        Label(selectCampScreen, text="Camp Location-Availability").pack(padx=10,pady=15)

        campList = Listbox(selectCampScreen)
        campList.pack(padx=5, pady=5)
                
        for idx, camp in enumerate(self.campDb):
            campList.insert(idx, f"{camp[0]} - {camp[1]}")


        Button(selectCampScreen, text="Select Camp", padx=5, pady=5, command=lambda: self.__onSelectCamp(
            campList,label,selectCampScreen)).pack()

        selectCampScreen.mainloop()

    def __onSelectCamp(self, campList, label, selectCampScreen):
        index = campList.curselection()
        if not index: return

        camp = self.campDb[index[0]]

        if(camp[1] == 0):
            messagebox.showerror("Not Available", "This camp is not available anymore")
            selectCampScreen.destroy()
            return

        label.config(text=camp[0])
        self.campDb[index[0]][1] -= 1

        selectCampScreen.destroy()
