import enum


class UserLevel(enum.Enum):
    CUSTOMER = 4
    ADVISOR = 8
    ADMIN = 16