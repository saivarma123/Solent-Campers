class ApplicationState:
    isAuthenticated = False
    currentUser = None


class Constants:
    admin = "Administrator"
    advisor = "Advisor"
    customer = "Customer"
