from tkinter import *
from AdministratorManagementSystem import AdministratorManagementSystem
from AdvisorManagementSystem import AdvisorManagementSystem
from AuthenticationManagementSystem import AuthenticationManagementSystem
from CustomerManagementSystem import CustomerManagementSystem
from state import *
from model import UserLevel

if __name__ == "__main__":
    AuthenticationManagementSystem().showUserSelection()

    if ApplicationState.isAuthenticated:
        if ApplicationState.currentUser == UserLevel.CUSTOMER:
            CustomerManagementSystem().showCustomerScreen()
        elif ApplicationState.currentUser == UserLevel.ADVISOR:
            AdvisorManagementSystem().showAdvisorScreen()
        elif ApplicationState.currentUser == UserLevel.ADMIN:
            AdministratorManagementSystem().showAdministratorScreen()