from tkinter import *

class CustomerManagementSystem:
    def __init__(self):
        self.__rootScreen = Tk()
        self.__rootScreen.title("Solent Campers")

        self.__bookingList = Listbox(self.__rootScreen)
        self.__bookingList.pack(padx=5, pady=5)

        self.__bookingList.insert("0","Winter Camping Trip")

        Button(self.__rootScreen, text="View bookings",command=lambda:self.viewDetails()).pack()

        self.__detailsLabel = Label(self.__rootScreen, text="Details shown here")
        self.__detailsLabel.pack(pady=5)


    def showCustomerScreen(self):
        self.__rootScreen.mainloop()


    def viewDetails(self):
        index = self.__bookingList.curselection()
        if not index: return
        
        index = index[0] if index else 0
        
        detailsText = """
Details shown here

Camper Van: Small (S) Size
Camp Spot: Valley bottom camping site
        """

        self.__detailsLabel.config(text=detailsText)